/* global QUnit */

sap.ui.require(["projecttest/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
