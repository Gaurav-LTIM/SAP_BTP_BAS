sap.ui.define([
	"project_test/test/unit/controller/MainPageView1.controller"
], function () {
	"use strict";
});
