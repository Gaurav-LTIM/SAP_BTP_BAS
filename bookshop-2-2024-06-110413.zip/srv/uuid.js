import {v4 as uuidv4} from 'uuid';

let myuuid = uuidv4();

console.log('Your UUID is: ' + myuuid);