sap.ui.define([
	"project_emp_ui/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});
